export interface CreatePoli {
  username: string;
  nama: string;
  password: string;
}
